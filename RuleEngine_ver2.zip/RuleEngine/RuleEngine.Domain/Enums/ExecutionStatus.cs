namespace RuleEngine.Domain.Enums;

public enum ExecutionStatus
{
    Success,
    Failed,
    Skipped
}
