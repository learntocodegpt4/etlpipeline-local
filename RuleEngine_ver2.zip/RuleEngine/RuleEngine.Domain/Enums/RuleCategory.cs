namespace RuleEngine.Domain.Enums;

public enum RuleCategory
{
    PayRate,
    Allowance,
    Classification,
    Compliance
}
