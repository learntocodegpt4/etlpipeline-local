namespace RuleEngine.Domain.Enums;

public enum RuleType
{
    Simple,
    Complex
}
