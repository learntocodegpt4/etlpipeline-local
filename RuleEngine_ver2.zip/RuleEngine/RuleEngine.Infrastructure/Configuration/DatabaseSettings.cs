namespace RuleEngine.Infrastructure.Configuration;

public class DatabaseSettings
{
    public string ConnectionString { get; set; } = string.Empty;
}
